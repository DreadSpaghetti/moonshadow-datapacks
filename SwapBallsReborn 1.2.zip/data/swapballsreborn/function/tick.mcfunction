tag @a[tag=!SwappedBalled,nbt={SelectedItem:{id:"minecraft:sugar",components:{"minecraft:custom_model_data":1}}},predicate=!swapballsreborn:holdingsugar2,predicate=!swapballsreborn:holdingsugar3,predicate=!swapballsreborn:holdingsugar4,predicate=!swapballsreborn:holdingsugar5,predicate=!swapballsreborn:holdingsugar6,predicate=swapballsreborn:holdingball,predicate=swapballsreborn:sneaking,limit=1,sort=random] add SwapBall

tag @a[tag=!SwappedBalled,nbt={SelectedItem:{id:"minecraft:sugar",components:{"minecraft:custom_model_data":1}}},predicate=swapballsreborn:holdingsugar2,predicate=!swapballsreborn:holdingsugar3,predicate=!swapballsreborn:holdingsugar4,predicate=!swapballsreborn:holdingsugar5,predicate=!swapballsreborn:holdingsugar6,predicate=swapballsreborn:holdingball,predicate=swapballsreborn:sneaking,limit=1,sort=random] add SwapBall2

tag @a[tag=!SwappedBalled,nbt={SelectedItem:{id:"minecraft:sugar",components:{"minecraft:custom_model_data":1}}},predicate=!swapballsreborn:holdingsugar2,predicate=swapballsreborn:holdingsugar3,predicate=!swapballsreborn:holdingsugar4,predicate=!swapballsreborn:holdingsugar5,predicate=!swapballsreborn:holdingsugar6,predicate=swapballsreborn:holdingball,predicate=swapballsreborn:sneaking,limit=1,sort=random] add SwapBall3

tag @a[tag=!SwappedBalled,nbt={SelectedItem:{id:"minecraft:sugar",components:{"minecraft:custom_model_data":1}}},predicate=!swapballsreborn:holdingsugar2,predicate=!swapballsreborn:holdingsugar3,predicate=swapballsreborn:holdingsugar4,predicate=!swapballsreborn:holdingsugar5,predicate=!swapballsreborn:holdingsugar6,predicate=swapballsreborn:holdingball,predicate=swapballsreborn:sneaking,limit=1,sort=random] add SwapBall4

tag @a[tag=!SwappedBalled,nbt={SelectedItem:{id:"minecraft:sugar",components:{"minecraft:custom_model_data":1}}},predicate=!swapballsreborn:holdingsugar2,predicate=!swapballsreborn:holdingsugar3,predicate=!swapballsreborn:holdingsugar4,predicate=swapballsreborn:holdingsugar5,predicate=!swapballsreborn:holdingsugar6,predicate=swapballsreborn:holdingball,predicate=swapballsreborn:sneaking,limit=1,sort=random] add SwapBall5

tag @a[tag=!SwappedBalled,nbt={SelectedItem:{id:"minecraft:sugar",components:{"minecraft:custom_model_data":1}}},predicate=!swapballsreborn:holdingsugar2,predicate=!swapballsreborn:holdingsugar3,predicate=!swapballsreborn:holdingsugar4,predicate=!swapballsreborn:holdingsugar5,predicate=swapballsreborn:holdingsugar6,predicate=swapballsreborn:holdingball,predicate=swapballsreborn:sneaking,limit=1,sort=random] add SwapBall6

execute as @a[tag=SwapBall] run function swapballsreborn:swapball
execute as @a[tag=SwapBall2] run function swapballsreborn:swapball2
execute as @a[tag=SwapBall3] run function swapballsreborn:swapball3
execute as @a[tag=SwapBall4] run function swapballsreborn:swapball4
execute as @a[tag=SwapBall5] run function swapballsreborn:swapball5
execute as @a[tag=SwapBall6] run function swapballsreborn:swapball6

execute as @a unless entity @s[predicate=swapballsreborn:sneaking] run tag @s remove SwappedBalled
tag @a remove SwapBall
tag @a remove SwapBall2
tag @a remove SwapBall3
tag @a remove SwapBall4
tag @a remove SwapBall5
tag @a remove SwapBall6