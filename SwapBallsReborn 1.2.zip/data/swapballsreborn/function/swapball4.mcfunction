pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:poke_ball"}]}] 4 pokeball=poke_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:citrine_ball"}]}] 4 pokeball=citrine_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:verdant_ball"}]}] 4 pokeball=verdant_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:azure_ball"}]}] 4 pokeball=azure_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:roseate_ball"}]}] 4 pokeball=roseate_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:slate_ball"}]}] 4 pokeball=slate_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:premier_ball"}]}] 4 pokeball=premier_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:great_ball"}]}] 4 pokeball=great_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ultra_ball"}]}] 4 pokeball=ultra_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:safari_ball"}]}] 4 pokeball=safari_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:fast_ball"}]}] 4 pokeball=fast_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:level_ball"}]}] 4 pokeball=level_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:lure_ball"}]}] 4 pokeball=lure_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:heavy_ball"}]}] 4 pokeball=heavy_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:love_ball"}]}] 4 pokeball=love_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:friend_ball"}]}] 4 pokeball=friend_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:moon_ball"}]}] 4 pokeball=moon_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:sport_ball"}]}] 4 pokeball=sport_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:park_ball"}]}] 4 pokeball=park_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:net_ball"}]}] 4 pokeball=net_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:dive_ball"}]}] 4 pokeball=dive_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:nest_ball"}]}] 4 pokeball=nest_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:repeat_ball"}]}] 4 pokeball=repeat_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:timer_ball"}]}] 4 pokeball=timer_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:luxury_ball"}]}] 4 pokeball=luxury_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:dusk_ball"}]}] 4 pokeball=dusk_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:heal_ball"}]}] 4 pokeball=heal_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:quick_ball"}]}] 4 pokeball=quick_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:dream_ball"}]}] 4 pokeball=dream_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:beast_ball"}]}] 4 pokeball=beast_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:master_ball"}]}] 4 pokeball=master_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:cherish_ball"}]}] 4 pokeball=cherish_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_poke_ball"}]}] 4 pokeball=ancient_poke_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_citrine_ball"}]}] 4 pokeball=ancient_citrine_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_verdant_ball"}]}] 4 pokeball=ancient_verdant_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_azure_ball"}]}] 4 pokeball=ancient_azure_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_roseate_ball"}]}] 4 pokeball=ancient_roseate_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_slate_ball"}]}] 4 pokeball=ancient_slate_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_ivory_ball"}]}] 4 pokeball=ancient_ivory_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_great_ball"}]}] 4 pokeball=ancient_great_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_ultra_ball"}]}] 4 pokeball=ancient_ultra_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_feather_ball"}]}] 4 pokeball=ancient_feather_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_wing_ball"}]}] 4 pokeball=ancient_wing_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_jet_ball"}]}] 4 pokeball=ancient_jet_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_heavy_ball"}]}] 4 pokeball=ancient_heavy_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_leaden_ball"}]}] 4 pokeball=ancient_leaden_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_gigaton_ball"}]}] 4 pokeball=ancient_gigaton_ball
pokeeditother @p[tag=SwapBall4,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_origin_ball"}]}] 4 pokeball=ancient_origin_ball

item modify entity @p[tag=SwapBall4] weapon.offhand swapballsreborn:clearone
item modify entity @p[tag=SwapBall4] weapon.mainhand swapballsreborn:clearone

execute at @p[tag=SwapBall4] run playsound cobblemon:poke_ball.capture_started master @a[distance=..10] ~ ~1 ~ 0.75 2 0
execute at @p[tag=SwapBall4] run playsound cobblemon:pc.grab master @a[distance=..10] ~ ~1 ~ 1 0 0

execute at @p[tag=SwapBall4] run particle poof ^ ^1 ^1 .1 .1 .1 0.1 30
execute at @p[tag=SwapBall4] run particle heart ^ ^0.9 ^1 .3 .3 .3 0.1 3
tag @p[tag=SwapBall4] add SwappedBalled