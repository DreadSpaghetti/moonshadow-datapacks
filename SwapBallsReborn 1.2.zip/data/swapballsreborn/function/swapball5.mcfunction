pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:poke_ball"}]}] 5 pokeball=poke_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:citrine_ball"}]}] 5 pokeball=citrine_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:verdant_ball"}]}] 5 pokeball=verdant_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:azure_ball"}]}] 5 pokeball=azure_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:roseate_ball"}]}] 5 pokeball=roseate_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:slate_ball"}]}] 5 pokeball=slate_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:premier_ball"}]}] 5 pokeball=premier_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:great_ball"}]}] 5 pokeball=great_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ultra_ball"}]}] 5 pokeball=ultra_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:safari_ball"}]}] 5 pokeball=safari_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:fast_ball"}]}] 5 pokeball=fast_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:level_ball"}]}] 5 pokeball=level_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:lure_ball"}]}] 5 pokeball=lure_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:heavy_ball"}]}] 5 pokeball=heavy_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:love_ball"}]}] 5 pokeball=love_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:friend_ball"}]}] 5 pokeball=friend_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:moon_ball"}]}] 5 pokeball=moon_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:sport_ball"}]}] 5 pokeball=sport_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:park_ball"}]}] 5 pokeball=park_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:net_ball"}]}] 5 pokeball=net_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:dive_ball"}]}] 5 pokeball=dive_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:nest_ball"}]}] 5 pokeball=nest_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:repeat_ball"}]}] 5 pokeball=repeat_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:timer_ball"}]}] 5 pokeball=timer_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:luxury_ball"}]}] 5 pokeball=luxury_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:dusk_ball"}]}] 5 pokeball=dusk_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:heal_ball"}]}] 5 pokeball=heal_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:quick_ball"}]}] 5 pokeball=quick_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:dream_ball"}]}] 5 pokeball=dream_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:beast_ball"}]}] 5 pokeball=beast_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:master_ball"}]}] 5 pokeball=master_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:cherish_ball"}]}] 5 pokeball=cherish_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_poke_ball"}]}] 5 pokeball=ancient_poke_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_citrine_ball"}]}] 5 pokeball=ancient_citrine_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_verdant_ball"}]}] 5 pokeball=ancient_verdant_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_azure_ball"}]}] 5 pokeball=ancient_azure_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_roseate_ball"}]}] 5 pokeball=ancient_roseate_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_slate_ball"}]}] 5 pokeball=ancient_slate_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_ivory_ball"}]}] 5 pokeball=ancient_ivory_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_great_ball"}]}] 5 pokeball=ancient_great_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_ultra_ball"}]}] 5 pokeball=ancient_ultra_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_feather_ball"}]}] 5 pokeball=ancient_feather_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_wing_ball"}]}] 5 pokeball=ancient_wing_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_jet_ball"}]}] 5 pokeball=ancient_jet_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_heavy_ball"}]}] 5 pokeball=ancient_heavy_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_leaden_ball"}]}] 5 pokeball=ancient_leaden_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_gigaton_ball"}]}] 5 pokeball=ancient_gigaton_ball
pokeeditother @p[tag=SwapBall5,limit=1,nbt={Inventory:[{Slot:-106b,id:"cobblemon:ancient_origin_ball"}]}] 5 pokeball=ancient_origin_ball

item modify entity @p[tag=SwapBall5] weapon.offhand swapballsreborn:clearone
item modify entity @p[tag=SwapBall5] weapon.mainhand swapballsreborn:clearone

execute at @p[tag=SwapBall5] run playsound cobblemon:poke_ball.capture_started master @a[distance=..10] ~ ~1 ~ 0.75 2 0
execute at @p[tag=SwapBall5] run playsound cobblemon:pc.grab master @a[distance=..10] ~ ~1 ~ 1 0 0

execute at @p[tag=SwapBall5] run particle poof ^ ^1 ^1 .1 .1 .1 0.1 30
execute at @p[tag=SwapBall5] run particle heart ^ ^0.9 ^1 .3 .3 .3 0.1 3
tag @p[tag=SwapBall5] add SwappedBalled